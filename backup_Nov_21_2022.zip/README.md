Password Hashing in NodeJS using Bcrypt
Prerequisites

    Basic Understanding of Node and JavaScript.
    Node and NPM installed.

How to Start

    Run npm install
    
    In a seperate terminal run 
    sudo mongod
    
    to access the database, in a seperate terminal, run
    run mongo
    
    Run node server.js
    npm start
    Server will be running at locahost:5000
