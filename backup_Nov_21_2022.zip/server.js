const express = require("express")
const app = express()
const PORT = 5000
const connectDB = require("./db");
const cookieParser = require("cookie-parser");
const bodyParser = require('body-parser');
const stripe = require('stripe')('sk_test_51M2mNpCyYVSsKZLoeOG3sbmhoo4n6Q1c9DBEYiMznjT7JrXS4eW2bcROZU2EBLTknFcJmhLqighHIYPMlbyNPUQa00GsQso4VK');
const { adminAuth, userAuth, userIsLoggedIn, userIsLoggedInTrueOrFalse } = require("./middleware/auth.js");
//Connecting the Database
connectDB();


//app.listen(PORT, () => console.log(`Server Connected to port! ${PORT}`))
const server = app.listen(PORT, () =>
  console.log(`Server Connected to port! ${PORT}`)
)
// Handling Error
process.on("unhandledRejection", err => {
  console.log(`An error occurred: ${err.message}`)
  server.close(() => process.exit(1))
})

app.set("view engine", "ejs")

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.json())
//binding middleware to an instance of the app object
app.use("/api/auth", require("./Auth/route"))
//all paths with use cookieParser
app.use(cookieParser());
app.use("/public", express.static("./public"));




app.locals.title = 'UserNM';


app.get("/home", userIsLoggedInTrueOrFalse, (req, res) => res.render("home", {"isLoggedIn" : req.isLoggedIn, "userFromReq" : req.user}))
app.get("", userIsLoggedInTrueOrFalse, (req, res) => res.render("home", {"isLoggedIn" : req.isLoggedIn, "userFromReq" : req.user}))
app.get("/register", userIsLoggedInTrueOrFalse, (req, res) => res.render("register", {"isLoggedIn" : req.isLoggedIn, "userFromReq" : req.user}))
app.get("/registerWithToken", userIsLoggedInTrueOrFalse, (req, res) => res.render("registerWithToken", {"isLoggedIn" : req.isLoggedIn, "userFromReq" : req.user}))
app.get("/login", userIsLoggedInTrueOrFalse, (req, res) => res.render("login", {"userNM" : req.title, "userFromReq": req.user, "logdetails":"", "isLoggedIn" : req.isLoggedIn}))
app.get("/admin", adminAuth, (req, res) => res.render("admin"))
app.get("/basic", userAuth, (req, res) => res.render("user"))
app.get("/payments", userAuth, userIsLoggedInTrueOrFalse, (req, res) => res.render("payments", {"isLoggedIn" : req.isLoggedIn, "userFromReq" : req.user}))
app.get("/logout", (req, res) => {
  res.cookie("jwt", "", { maxAge: "1" })
  res.redirect("/")
})
//create middleware to grab user token
app.get("/myaccount", userIsLoggedInTrueOrFalse, function (req, res) {
  if (req.isLoggedIn == true ){
    res.render("myaccount", {"isLoggedIn" : req.isLoggedIn, "userFromReq" : req.user, "userToken" : req.userToken, "apiToken" : req.apiToken});
  }
  else{
    res.render("login", {"userNM" : req.title, "userFromReq": req.user, "logdetails":"", "isLoggedIn" : req.isLoggedIn})
  }
}) 

app.get('/secFiles/:fileNum', userIsLoggedInTrueOrFalse, function (req, res) {
  if (req.isLoggedIn == true ){
    let pathToFile = "./Sec_fiings/resources/companies/" + req.params['fileNum'];
    res.download(pathToFile + ".zip", req.params['fileNum']);
  }
  else{
    res.render("login", {"userNM" : req.title, "userFromReq": req.user, "logdetails":"", "isLoggedIn" : req.isLoggedIn})
  }
  console.log(req.params['fileNum']);
  //Sec_fiings/resources/companies/1000032.zip
})

app.get('/file/:name', function (req, res, next) {
  let options = {
    root: path.join(__dirname, './public'),
    dotfiles: 'deny',
    headers: {
      'x-timestamp': Date.now(),
      'x-sent': true
    }
  }
  console.log("here")
  let fileName = req.params.name
  res.sendFile(fileName, options, function (err) {
    if (err) {
      console.log("here")
      next(err)
    } else {
      console.log('Sent:', fileName)
    }
  })
})

app.post("/charge", (req, res) => {
  console.log("posted to charge");
  console.log("req body : \n" + req.body);
  //make this like the registerwithtoken routes
  try {
    stripe.customers
      .create({
        name: req.body.name,
        email: req.body.email,
        source: req.body.stripeToken
      })
      .then(() => {
        console.log("created stripe customer");
      })
      .then(customer =>
        stripe.charges.create({
          amount: req.body.amount * 100,
          currency: "usd",
          customer: customer.id
        })
      )
      .then(() => {
        console.log("Charge Successful");
        res.render("/home")
      })
      .catch(err => {
        console.log("there was an error (server.js app.post): " + err)}
        );
  } catch (err) {
    res.send(err);
  }
});

//will break css and js if this line isn't at end of file
app.use(express.static(__dirname + '/public'));

